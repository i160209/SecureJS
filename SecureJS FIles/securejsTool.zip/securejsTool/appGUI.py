
class AppGUI:
	def __init__(self):
		print("Application GUI Class")
	def displayGUI(self):
		print("Dataset.displayDataMetrics() executed")