class Documentation:
	def __init__(self):
		print("")
	def displayhelp(self):
		print("Documentation.displayhelp() executed")
