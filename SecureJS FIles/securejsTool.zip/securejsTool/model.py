class Model:
	def __init__(self):
		print("")
	def buildModel(self):
		print("Model.buildModel() executed")